package com.example.grade_service.controller;

import com.example.grade_service.model.Grade;
import com.example.grade_service.service.GradeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/grades")
public class GradeController {
    @Autowired
    private GradeService gradeService;

    @GetMapping
    public List<Grade> getAllGrades() {
        return gradeService.getAllGrades();
    }

    @GetMapping("/student/{id}")
    public List<Grade> getGradesByStudentId(@PathVariable Long id) {
        return gradeService.getGradesByStudentId(id);
    }

    @GetMapping("/course/{id}")
    public List<Grade> getGradesByCourseId(@PathVariable Long id) {
        return gradeService.getGradesByCourseId(id);
    }

    @PostMapping
    public Grade addGrade(@RequestBody Grade grade) {
        return gradeService.addGrade(grade);
    }

    @PutMapping("/{id}")
    public Grade updateGrade(@PathVariable Long id, @RequestBody Grade grade) {
        return gradeService.updateGrade(id, grade);
    }

    @DeleteMapping("/{id}")
    public void deleteGrade(@PathVariable Long id) {
        gradeService.deleteGrade(id);
    }
}
